<?php

echo "teste";